
from django.contrib.auth.forms import UserCreationForm
from django import forms
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, ButtonHolder, Submit
from .models import Membership


class MembershipForm(forms.ModelForm):
    class Meta:
        model = Membership
        fields = (
            'first_name',
            'last_name',
            'state',
            'local_government',
            'ward',
            'phone',
            'email',
            'gender',

        )

    def __init__(self, *args, **kwargs):
        super(MembershipForm, self).__init__(*args, **kwargs)

        self.form_name = 'MembershipForm'
        self.helper = FormHelper()
        self.helper.layout = Layout(
            'first_name',
            'last_name',
            'state',
            'local_government',
            'ward',
            'phone',
            'email',
            'gender',

            ButtonHolder(
                Submit('register member', 'Register member', css_class='btn-primary')
            )
        )
