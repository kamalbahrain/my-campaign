from django.contrib import admin
from .models import Membership


# Register your models here.
admin.site.register(Membership)
