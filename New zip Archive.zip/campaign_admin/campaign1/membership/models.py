from django.db import models

# Create your models here.

GENDER_TYPE = (
    ('MALE', 'MALE'),
    ('FEMALE', 'FEMALE')
)



class Membership(models.Model):
    first_name = models.CharField(max_length=250)
    last_name = models.CharField(max_length=250)
    state = models.CharField(max_length=250)
    local_government = models.CharField(max_length=250)
    ward = models.CharField(max_length=250)
    phone = models.CharField(max_length=15)
    email = models.EmailField(max_length=250, null=True)
    gender = models.CharField(max_length=10, null=True, choices=GENDER_TYPE)

    def __str__(self):
        return self.first_name

