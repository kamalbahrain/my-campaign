from django.conf.urls import url
from membership.views import *
from .import views
from django.views import generic



urlpatterns = [
    url(r'^$', MembershipForm.as_view(), name='membership'),


  ]
