from django.views import generic
from django.views.generic.base import TemplateView
from django.core.urlresolvers import reverse_lazy
from .forms import *
from .models import Membership



# Create your views here.
class MembershipForm(generic.CreateView):
    form_class = MembershipForm
    template_name = 'events/membership.html'
    # success_url = reverse_lazy('membership:membership')



# # Create your views here.
# class MembershipView(TemplateView):
#     template_name = 'events/membership.html'
#
# def add_member(request):
#     if request.method == 'POST':
#         form = MembershipForm(request.POST)
#         return render(request, 'events/membership.html', {'form': form})
#






