from django.apps import AppConfig


class MemberdetailsConfig(AppConfig):
    name = 'memberdetails'
