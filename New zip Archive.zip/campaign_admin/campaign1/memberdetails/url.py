

from django.conf.urls import url
from .import views



urlpatterns = [
   url(r'^$', views.MembersDetailsView.as_view(),name='memberdetails'),

  ]
