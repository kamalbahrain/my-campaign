from django.shortcuts import render
from membership.models import Membership
from django.views import generic
from django.views.generic.base import TemplateView

# Create your views here.
class MembersDetailsView(generic.TemplateView):
    template_name = 'events/memberdetails.html'

    # def __init__(self):
    #     detail= Membership.objects.all()
    #     return self.first_name()
    #
