from django.db import models

# Create your models here.
class Song(models.Model):
    song_title = models.CharField(max_length=50, null=True, blank=True)
    artist = models.CharField(max_length=50, null=True, blank=True)
    music = models.FileField(verbose_name='Music', null=True, blank=True)
    file_type = models.CharField(max_length=50, null=True, blank=True)
