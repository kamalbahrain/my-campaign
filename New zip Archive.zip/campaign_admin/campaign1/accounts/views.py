from __future__ import absolute_import
from django.views.generic.base import TemplateView
from django.views import generic
from .forms import LoginForm
from django.contrib.auth import authenticate, login, logout
from django.core.urlresolvers import reverse_lazy


# Create your views here.
class LoginView(generic.FormView):
    form_class = LoginForm
    success_url = reverse_lazy('Posts')
    template_name = 'events/login.html'

    def form_valid(self, form):
        username = form.cleaned_data['username']
        password = form.cleaned_data['password']
        user = authenticate(username=username, password=password)

        if user is not None and user.is_active:
            login(self.request, user)
            return super(LoginView, self).form_valid(form)
        else:
            return self.form_invalid(form)

