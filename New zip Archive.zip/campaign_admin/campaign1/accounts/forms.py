from django.contrib.auth.forms import AuthenticationForm
from django import forms
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, ButtonHolder, Submit


class LoginForm(AuthenticationForm):
    def __init__(self, *args, **kwargs):
        super(LoginForm, self).__init__(*args, **kwargs)

        self.helper = FormHelper()
        self.helper.form_method = 'post'
        self.helper.form_action = 'login'
        self.helper.layout = Layout(
            'username',
            'password',
            self.helper.add_input(Submit('submit', 'Submit'))
            # ButtonHolder(
            #     Submit('login', 'Login', css_class='btn btn-info btn-round btn-lg btn-block')
            # )

        )
