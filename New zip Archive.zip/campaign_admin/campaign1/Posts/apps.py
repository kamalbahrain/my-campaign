from django.apps import AppConfig


class PostConfig(AppConfig):
    name = 'Posts'
