from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Posts
from .models import UpcomingEvents
from .forms import Mailform

# Create your views here.
def post(request):
    top_posts = Posts.objects.all()[::-1]
    event_list = UpcomingEvents.objects.all()
    form = Mailform



    context = {'top_posts': top_posts, 'event_list': event_list, 'form': form}

    return render(request, 'events/index.html', context)




# def get(self, request):
#         form = Mailform
#         # return render(request, self.events/index.html, {'form': form})
#
# # def post(self, request):
# #     form = Mailform(request.POST)
# #     if form.is_valid():
# #         POST.form.save(commit=False)
# #         text = form.changed_data['POST']
# #         form = Mailform()
#
#
#     return redirect('index:index')
