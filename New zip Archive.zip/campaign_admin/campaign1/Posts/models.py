
from django.db import models
from django.contrib.auth.models import User


# Create your models here.
class Posts(models.Model):
    postImage = models.ImageField(upload_to='Posts/post_images', blank=True)
    postHeader = models.CharField(max_length=250, null=True, blank=True)
    post = models.CharField(max_length=5000, null=True)
    # user = models.ForeignKey(User)
    # date = models.DateTimeField(auto_now=True)




class UpcomingEvents(models.Model):
    events = models.CharField(max_length=5000, null=True)
    schedule = models.DateTimeField(null=True, blank=True)
    venue = models.CharField(max_length=250, null=True, blank=True)


    def __str__(self):
        return self.events + ' - ' + self.venue


class Email(models.Model):
    mail = models.EmailField(max_length=500, null=True, blank=True)
    # user = models.ForeignKey(User)
