from django import forms
from .models import Email
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, ButtonHolder, Submit


class Mailform(forms.ModelForm):
    class Meta:
        model = Email
        fields = ('mail',)

        def __init__(self, *args, **kwargs):
            super(Mailform, self).__init__(*args, **kwargs)

            self.form_name = 'email_form'
            self.helper = FormHelper()
            self.helper.layout = Layout(
                'Email',
                ButtonHolder(
                    Submit('register ', "Register Email", css_class='btn btn-info btn-round btn-lg btn-block')
                )

            )
