from django.contrib import admin
from .models import Posts, UpcomingEvents, Email
# Register your models here.
admin.site.register(Posts)
admin.site.register(UpcomingEvents)
admin.site.register(Email)
